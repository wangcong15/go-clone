#import <Foundation/Foundation.h>

//@protocol MatchaMiddleware
//@end
//
//typedef id<MatchaMiddleware> (^MatchaMiddlewareBlock)(void);
//
//void MatchaRegisterMiddleware(MatchaMiddlewareBlock block);
//NSArray<MatchaMiddlewareBlock> *MatchaMiddlewares();
