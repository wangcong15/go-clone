#import <Foundation/Foundation.h>

@interface MatchaDeadlockLogger : NSObject
+ (instancetype)sharedLogger;
@end
