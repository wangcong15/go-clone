//
//  MatchaBridge.h
//  MatchaBridge
//
//  Created by Kevin Dang on 7/2/17.
//  Copyright © 2017 Matcha. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MatchaBridge.
FOUNDATION_EXPORT double MatchaBridgeVersionNumber;

//! Project version string for MatchaBridge.
FOUNDATION_EXPORT const unsigned char MatchaBridgeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MatchaBridge/PublicHeader.h>

#import <MatchaBridge/matchaforeign.h>
#import <MatchaBridge/matchago.h>
